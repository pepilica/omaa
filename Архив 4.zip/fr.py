import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QListWidgetItem
from PyQt5.QtWidgets import QMainWindow


class Memo(QMainWindow):
    def __init__(self):
        super().__init__()
        self.arr = []
        uic.loadUi('contacts.ui', self)
        self.pushButton.clicked.connect(self.add)

    def add(self):
        if self.lineEdit.text().isdigit():
            a = self.name.text()
            self.error.setText('')
            num = self.lineEdit.text()
            self.listView.clear()
            self.arr.append([str(a), str(num)])
            biba = QListWidgetItem('\n'.join(['\t'.join(i) for i in sorted(self.arr, key=lambda x: x[1])]))
            self.listView.addItem(biba)
        else:
            self.error.setText('Введите корректный номер')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mc = Memo()
    mc.show()
    sys.exit(app.exec())