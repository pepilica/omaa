import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QListWidgetItem
from PyQt5.QtWidgets import QMainWindow, QPushButton


class Memo(QMainWindow):
    def __init__(self):
        super().__init__()
        self.arr = []
        uic.loadUi('pixel.ui', self)
        self.begin.clicked.connect(self.build)

    def build(self):
        with open('input.txt', mode='r') as f:
            text = f.read()
            z = []
            if text:
                for i in text.split('\n'):
                    z += [bool(int(j)) for j in i]
            else:
                for i in range(5):
                    z += [False for _ in range(5)]
            for i, j in enumerate(self.buttonGroup.buttons()):
                if z[i]:
                    j.setStyleSheet(f"background-color: black")
                else:
                    j.setStyleSheet(f'background-color: white')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mc = Memo()
    mc.show()
    sys.exit(app.exec())