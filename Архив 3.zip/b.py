#! /usr/bin/env python
# -*- coding: utf-8 -*-

import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QApplication


class Cross(QMainWindow):
    def __init__(self):
        self.matrix = [None for i in range(9)]
        self.num = 0
        self.win = False
        self.state = 'X'
        super().__init__()
        uic.loadUi('cross.ui', self)
        for i in self.buttonGroup.buttons():
            i.clicked.connect(self.mark)

    def check(self):
        WAYS_TO_WIN = ((0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6), (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6))
        for row in WAYS_TO_WIN:
            if self.matrix[row[0]] == self.matrix[row[1]] == self.matrix[row[2]] is not None:
                winner = self.matrix[row[0]]
                return winner

    def mark(self):
        z = self.sender().text()
        if z not in '0X' and not self.win:
            self.matrix[int(z) - 1] = self.state
            self.num += 1
            a = self.check()
            if a:
                self.win = True
                self.label.setText(f'{a} выиграл')
            elif self.num == 9:
                self.win = True
                self.label.setText('ничья')
            self.sender().setText(self.state)
            if self.state == 'X':
                self.state = '0'
            else:
                self.state = 'X'


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mc = Cross()
    mc.show()
    sys.exit(app.exec())
