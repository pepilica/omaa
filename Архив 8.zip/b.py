from PyQt5.QtWidgets import QApplication, QWidget, QFileDialog
from PyQt5.QtWidgets import QPushButton, QLineEdit,QLabel
from PyQt5.QtGui import QPixmap
from PyQt5 import uic
import sys
import random
SCREEN_SIZE = [600, 600]

class Example(QWidget):
    def __init__(self):
        super().__init__()
        self.matches = 37
        uic.loadUi('spichka.ui', self)
        self.check = False
        self.turn = False
        self.pushButton.clicked.connect(self.move)

    def move(self):
        num = self.num_player.value()
        self.text_label.setText('')
        self.matches -= num
        if self.matches == 0:
            self.text_label.setText('Победили вы')
            self.pushButton.setEnabled(False)
            self.check = False
        if self.check:
            self.turn = True
            if self.turn:
                if self.matches > 11:
                    self.matches -= random.choice([i for i in range(1, 6)])
                elif self.matches <= 11 and self.matches > 6:
                    if self.matches == 11:
                        self.matches -= 5
                    elif self.matches == 10:
                        self.matches -= 4
                    elif self.matches == 9:
                        self.matches -= 3
                    elif self.matches == 8:
                        self.matches -= 2
                    elif self.matches == 7:
                        self.matches -= 1
                elif self.matches == 6:
                    self.matches -= 1
                elif self.matches <= 5:
                    self.matches -= self.matches
                self.turn = False
            if self.matches == 0:
                self.label_text.setText('Победил компьютер')
                self.pushButton.setEnabled(False)
        self.num_label.setText(self.num_label.text()[:-2] + str(self.matches).rjust(2, ' '))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec())