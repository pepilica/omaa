from random import choice
import sys
from PyQt5.QtWidgets import QWidget, QApplication, QLabel
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt


class Example(QWidget):
    def __init__(self):
        super().__init__()
        self.setMouseTracking(True)
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Машинка')
        self.setGeometry(50, 50, 500, 500)
        self.setFixedSize(500, 500)
        self.pic_list = ['car1.png', 'car2.png', 'car3.png']
        self.pic = QPixmap(choice(self.pic_list))
        self.pic_container = QLabel(self)
        self.pic_container.move(225, 225)
        self.pic_container.resize(50, 50)
        self.pic_container.setPixmap(self.pic)


    def keyPressEvent(self, QKeyEvent):
        if QKeyEvent.key() == Qt.Key_Space:
            self.pic = QPixmap(choice(self.pic_list))
            self.pic_container.setPixmap(self.pic)

    def mouseMoveEvent(self, QMouseEvent):
        if QMouseEvent.x() in range(451) and QMouseEvent.y() in range(451):
            self.pic_container.move(QMouseEvent.x(), QMouseEvent.y())


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec_())
