import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QListWidgetItem
from PyQt5.QtWidgets import QMainWindow, QPushButton


class Memo(QMainWindow):
    def __init__(self):
        super().__init__()
        self.arr = []
        uic.loadUi('pixel.ui', self)
        for i in self.buttonGroup.buttons():
            i.clicked.connect(self.draw)

    def draw(self):
        self.sender().setStyleSheet(f"background-color: black")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mc = Memo()
    mc.show()
    sys.exit(app.exec())