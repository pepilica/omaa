import sys
from random import choice
from PyQt5.QtWidgets import QApplication, QListWidgetItem, QLabel, QWidget, QPushButton
from PyQt5 import uic

class Find(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('minmax.ui', self)
        self.pushButton.clicked.connect(self.count)

    def count(self):
        with open('lines.txt', encoding='utf-8') as f:
            nums = []
            num = ''
            for i in f.read():
                if i.isdigit() or i == '-':
                    num += i
                elif num:
                    nums.append(int(num))
                    num = ''
        if nums:
            mi = min(nums)
            ma = max(nums)
            mid = sum(nums) / len(nums)
            self.l_min.setText(f'Min: {mi}')
            self.l_max.setText(f'Max: {ma}')
            self.l_med.setText(f'Medium: {mid}')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mc = Find()
    mc.show()
    sys.exit(app.exec())
