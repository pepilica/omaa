import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QListWidgetItem


class McDonalds(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('mcdonalds.ui', self)
        self.button_final.clicked.connect(self.final)

    def final(self):
        peremennaya = [(self.checkBox, self.spinBox), (self.checkBox_2, self.spinBox_2), (self.checkBox_3, self.spinBox_3), (self.checkBox_4, self.spinBox_4),
                       (self.checkBox_5, self.spinBox_5), (self.checkBox_6, self.spinBox_6), (self.checkBox_7, self.spinBox_7), (self.checkBox_8, self.spinBox_8),
                       (self.checkBox_9, self.spinBox_9), (self.checkBox_10, self.spinBox_10), (self.checkBox_11, self.spinBox_11), (self.checkBox_12, self.spinBox_12),
                       (self.checkBox_13, self.spinBox_13), (self.checkBox_14, self.spinBox_14), (self.checkBox_15, self.spinBox_15), (self.checkBox_16, self.spinBox_16),
                       (self.checkBox_17, self.spinBox_17), (self.checkBox_18, self.spinBox_18), (self.checkBox_19, self.spinBox_19), (self.checkBox_20, self.spinBox_20)]
        summa = 0
        checked = []
        self.lineEdit.clear()
        for i in peremennaya:
            if i[0].isChecked():
                num = 1 if not i[1].value() else i[1].value()
                product, price = i[0].text().split(' - ')
                checked.append(product)
                summa += int(price) * num
                a = QListWidgetItem('\t'.join([product, price, str(num), str(int(price) * num)]))
                self.lineEdit.addItem(a)
        self.lineEdit.addItem(QListWidgetItem(f'Итого: {summa} рублей'))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    cal = McDonalds()
    cal.show()
    sys.exit(app.exec())