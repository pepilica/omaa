import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QApplication




class Cross(QMainWindow):
    def __init__(self):
        self.matrix = {1: (0, 0), 2: (0, 1), 3: (0, 2), 4: (1, 0), 5: (1, 1),
                       6: (1, 2), 7: (2, 0), 8: (2, 1), 9: (2, 2)}
        self.num = 0
        self.field = None
        self.win = False
        self.state = None
        super().__init__()
        uic.loadUi('cross.ui', self)
        for i in self.buttonGroup.buttons():
            i.clicked.connect(self.mark)
        self.btn_restart.clicked.connect(self.restart)

    def restart(self):
        self.field = [[None for _ in range(3)] for _ in range(3)]
        if self.zero.isChecked():
            self.state = '0'
        else:
            self.state = 'X'
        self.win = False
        self.num = 0
        self.label.setText('')

    def check(self):
        for i in range(3):
            if not self.field[i][0] or not (self.field[i][0] ==
                                            self.field[i][1] == self.field[i][2]):
                return False
            if not self.field[0][i] or not (self.field[0][i] ==
                                            self.field[1][i] == self.field[2][i])
        if not (self.field[0][0] ==
                self.field[1][1] ==
                self.field[2][2]) or (self.field[2][0] ==
                                      self.field[1][1] ==
                                      self.field[0][2]) or not self.field[1][1]:
            return False
        return True

    def mark(self):
        if self.sender().text() not in '0X' and not self.win:
            y, x = self.matrix[int(self.sender().text())]
            self.field[y][x] = self.state
            self.num += 1
            if self.check():
                self.win = True
                self.label.setText(f'{"крестики" if self.state == "X" else "нолики"} выиграли')
            elif self.num == 9:
                self.win = True
                self.label.setText('ничья')
            if self.state == 'X':
                self.state = '0'
            else:
                self.state = 'X'
            self.sender().setText(self.state)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mc = Cross()
    mc.show()
    sys.exit(app.exec())