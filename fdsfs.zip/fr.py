import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QListWidgetItem
from PyQt5.QtWidgets import QMainWindow


class Memo(QMainWindow):
    def __init__(self):
        super().__init__()
        self.arr = []
        uic.loadUi('calculator.ui', self)
        self.pushButton.clicked.connect(self.add)

    def add(self):
        date = self.dateTime.dateTime().toString('dd MM yyyy HH mm')
        print(date)
        a = self.name.text()
        d, m, y, h, mm = date.split(' ')
        date1 = [y, m, d, h, mm]
        self.arr.append([str(a), str(date)])
        self.listWidget.clear()
        biba = QListWidgetItem('\n'.join(['\t'.join(i) for i in sorted(self.arr, key=lambda x: x[1])]))
        self.listWidget.addItem(biba)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mc = Memo()
    mc.show()
    sys.exit(app.exec())