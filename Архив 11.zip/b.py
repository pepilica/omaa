from random import choice
import sys
from PyQt5.QtWidgets import QWidget, QApplication, QLabel
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
from PyQt5 import uic


class Example(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('textEdit.ui', self)
        self.btn_create.clicked.connect(self.create_f)
        self.btn_load.clicked.connect(self.edit_f)
        self.btn_save.clicked.connect(self.save_f)

    def create_f(self):
        with open('example.txt', mode='w') as a:
            pass

    def edit_f(self):
        with open('example.txt', mode='r') as f:
            self.file = f.read()
            self.textEdit.setText(self.file)

    def save_f(self):
        with open('example.txt', mode='w') as f:
            text = self.textEdit.toPlainText()
            f.write(text)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec_())
