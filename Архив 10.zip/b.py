from random import choice
import sys
from PyQt5.QtWidgets import QWidget, QApplication, QLabel
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt


class Example(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.move = 25
        self.setWindowTitle('Машинка')
        self.setGeometry(50, 50, 500, 500)
        self.setFixedSize(500, 500)
        self.pic = QPixmap('ufo.png')
        self.pic_container = QLabel(self)
        self.pic_container.move(225, 225)
        self.pic_container.resize(50, 50)
        self.pic_container.setPixmap(self.pic)

    def keyPressEvent(self, QKeyEvent):
        if QKeyEvent.key() == Qt.Key_Up:
            if self.pic_container.y() < self.move:
                self.pic_container.move(self.pic_container.x(), 500 -
                                        (self.move - self.pic_container.y()))
            else:
                self.pic_container.move(self.pic_container.x(), self.pic_container.y() - self.move)
        elif QKeyEvent.key() == Qt.Key_Down:
            if self.pic_container.y() + self.move > 500:
                self.pic_container.move(self.pic_container.x(), 500 - self.pic_container.y())
            else:
                self.pic_container.move(self.pic_container.x(), self.pic_container.y() + self.move)
        elif QKeyEvent.key() == Qt.Key_Left:
            if self.pic_container.x() < self.move:
                self.pic_container.move(500 - (self.move - self.pic_container.x()), self.pic_container.y())
            else:
                self.pic_container.move(self.pic_container.x() - self.move, self.pic_container.y())
        elif QKeyEvent.key() == Qt.Key_Right:
            if self.pic_container.x() + self.move > 500:
                self.pic_container.move(500 - self.pic_container.x(), self.pic_container.y())
            else:
                self.pic_container.move(self.pic_container.x() + self.move, self.pic_container.y())


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec_())
